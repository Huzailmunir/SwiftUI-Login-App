import SwiftUI

struct ContentView: View {
    
    @State var username: String = ""
    @State var password: String = ""
    @State var user_test: String = "H"
    @State var pass_test: String = "M"
    
    var body: some View {
        
        VStack {
            TextField("Enter Username:", text: $username).padding()
            TextField("Enter Passowrd:", text: $password).padding()
            
            Button("Submit") {
                if username == user_test && password == pass_test{
                    print("Access Granted")
                } else{
                    print("Access Denied")
                }
            }
        }
    }
}
